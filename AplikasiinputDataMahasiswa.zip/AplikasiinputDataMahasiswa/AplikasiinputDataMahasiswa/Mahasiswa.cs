﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplikasiinputDataMahasiswa
{
    class Mahasiswa
    {
        public string Nim { get; set; }
        public string Nama { get; set; }
        public string Kelas { get; set; }
        public int Nilai { get; set; }
        public string NilaiHuruf { get; set; }
    }
}
